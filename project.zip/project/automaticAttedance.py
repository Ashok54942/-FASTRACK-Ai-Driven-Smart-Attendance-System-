import tkinter as tk
from tkinter import ttk
import os
import cv2
import pandas as pd
import datetime
import time
from openpyxl import load_workbook
from openpyxl.utils import get_column_letter

haarcasecade_path = "haarcascade_frontalface_default.xml"
trainimagelabel_path = "TrainingImageLabel\\Trainner.yml"
trainimage_path = "TrainingImage"
studentdetail_path = "StudentDetails\\studentdetails.csv"
enrollment_map_path = "StudentDetails\\EnrollmentMapping.csv"
attendance_path = "Attendance"
subject_data_path = "course.csv"

def subjectChoose(text_to_speech):
    def load_subject_data():
        try:
            return pd.read_csv(subject_data_path)
        except FileNotFoundError:
            return pd.DataFrame(columns=["Program", "Semester", "Subject Name"])

    def update_semesters(event):
        selected_course = course_var.get()
        filtered = subject_df[subject_df['Program'] == selected_course]
        semester_var['values'] = filtered['Semester'].unique().tolist()
        semester_var.set('')
        subject_var.set('')
        subject_var['values'] = []

    def update_subjects(event):
        selected_course = course_var.get()
        selected_semester = semester_var.get()
        filtered = subject_df[
            (subject_df['Program'] == selected_course) & (subject_df['Semester'] == selected_semester)]
        subject_var['values'] = filtered['Subject Name'].unique().tolist()
        subject_var.set('')

    def load_enrollment_mapping():
        if os.path.exists(enrollment_map_path):
            df_map = pd.read_csv(enrollment_map_path)
            return dict(zip(df_map['IntID'], df_map['Enrollment']))
        return {}

    def FillAttendance():
        course = course_var.get()
        semester = semester_var.get()
        subject = subject_var.get()

        if not course or not semester or not subject:
            text_to_speech("Please select course, semester, and subject!")
            return

        now = time.time()
        future = now + 20  # 20 seconds attendance window

        try:
            recognizer = cv2.face.LBPHFaceRecognizer_create()
            if not os.path.exists(trainimagelabel_path):
                Notifica.config(text="Model not found, please train the model", bg="black", fg="yellow")
                Notifica.place(x=20, y=350)
                text_to_speech("Model not found, please train the model")
                return

            recognizer.read(trainimagelabel_path)
            face_cascade = cv2.CascadeClassifier(haarcasecade_path)

            df_student = pd.read_csv(studentdetail_path)
            enrollment_map = load_enrollment_mapping()

            cam = cv2.VideoCapture(0)
            font = cv2.FONT_HERSHEY_SIMPLEX
            col_names = ["Enrollment", "Name", "Timestamp"]
            attendance = pd.DataFrame(columns=col_names)

            while True:
                ret, im = cam.read()
                gray = cv2.cvtColor(im, cv2.COLOR_BGR2GRAY)
                faces = face_cascade.detectMultiScale(gray, 1.2, 5)

                for (x, y, w, h) in faces:
                    Id, conf = recognizer.predict(gray[y: y + h, x: x + w])
                    if conf < 70 and Id in enrollment_map:
                        enrollment = enrollment_map[Id]
                        student_row = df_student[df_student["Enrollment"] == enrollment]
                        if not student_row.empty:
                            name = student_row["Name"].values[0]
                            program = student_row["Program"].values[0]
                            sem = student_row["Semester"].values[0]

                            if program == course and sem == semester:
                                if enrollment not in attendance["Enrollment"].values:
                                    timestamp = datetime.datetime.now().strftime("%d-%m-%Y %H:%M")
                                    attendance.loc[len(attendance)] = [enrollment, name, timestamp]

                                cv2.rectangle(im, (x, y), (x + w, y + h), (0, 255, 0), 4)
                                cv2.putText(im, f"{enrollment}-{name}", (x + h, y), font, 0.8, (255, 255, 0), 2)
                            else:
                                cv2.rectangle(im, (x, y), (x + w, y + h), (255, 0, 0), 2)
                                cv2.putText(im, "Not in selected batch", (x + h, y), font, 0.6, (0, 0, 255), 2)
                    else:
                        cv2.rectangle(im, (x, y), (x + w, y + h), (0, 0, 255), 4)
                        cv2.putText(im, "Unknown", (x + h, y), font, 1, (0, 0, 255), 2)

                if time.time() > future:
                    break

                cv2.imshow("Filling Attendance...", im)
                if cv2.waitKey(30) & 0xFF == 27:
                    break

        except Exception as e:
            text_to_speech("Error during attendance. Please check console.")
            print(f"Error: {e}")
            return

        finally:
            cam.release()
            cv2.destroyAllWindows()

        attendance.drop_duplicates(subset=["Enrollment"], keep="first", inplace=True)

        if attendance.empty:
            Notifica.config(text="No attendance recorded!", bg="black", fg="red")
            text_to_speech("No face was recognized. No attendance marked.")
            Notifica.place(x=20, y=350)
            return

        folder_path = os.path.join(attendance_path, course, semester, subject)
        os.makedirs(folder_path, exist_ok=True)

        timestamp = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        excel_file_path = os.path.join(folder_path, f"{subject}_{timestamp}.xlsx")
        attendance.to_excel(excel_file_path, index=False)

        # Auto-fit and format timestamp
        wb = load_workbook(excel_file_path)
        ws = wb.active
        for col_idx, col in enumerate(ws.iter_cols(1, ws.max_column), start=1):
            max_length = 0
            for cell in col:
                if cell.column_letter == 'C' and cell.row != 1:  # Timestamp column
                    cell.number_format = 'DD-MM-YYYY HH:MM'
                if cell.value:
                    max_length = max(max_length, len(str(cell.value)))
            ws.column_dimensions[get_column_letter(col_idx)].width = max_length + 2
        wb.save(excel_file_path)

        Notifica.config(text=f"Attendance Filled Successfully for {subject}", bg="black", fg="yellow")
        text_to_speech(f"Attendance Filled Successfully for {subject}")
        Notifica.place(x=5, y=350)

    def Attf():
        course = course_var.get()
        semester = semester_var.get()
        subject = subject_var.get()
        if not subject or not course or not semester:
            text_to_speech("Please select the course, semester, and subject!")
        else:
            folder_path = os.path.join(attendance_path, course, semester, subject)
            os.makedirs(folder_path, exist_ok=True)
            os.startfile(folder_path)

    subject_window = tk.Tk()
    subject_window.title("Subject Selection")
    subject_window.geometry("600x400")
    subject_window.resizable(0, 0)
    subject_window.configure(background="black")

    tk.Label(subject_window, bg="black", relief=tk.RIDGE, bd=10, font=("arial", 30),
             text="Select Course, Semester, and Subject").pack(fill=tk.X)

    tk.Label(subject_window, text="Smart Attendance", bg="black", fg="sky blue",
             font=("Arial Rounded MT Bold", 25, "bold")).place(x=150, y=10)

    subject_df = load_subject_data()
    courses = subject_df['Program'].unique().tolist()

    tk.Label(subject_window, text="Program :", bg="black", fg="lime", font=("oleo script", 15, "bold")).place(x=120, y=90)
    course_var = ttk.Combobox(subject_window, values=courses, font=("oleo script", 15,), state="readonly")
    course_var.place(x=260, y=90)
    course_var.bind("<<ComboboxSelected>>", update_semesters)

    tk.Label(subject_window, text="Semester :", bg="black", fg="lime", font=("oleo script", 15, "bold")).place(x=120, y=140)
    semester_var = ttk.Combobox(subject_window, font=("oleo script", 15), state="readonly")
    semester_var.place(x=260, y=140)
    semester_var.bind("<<ComboboxSelected>>", update_subjects)

    tk.Label(subject_window, text="Subject :", bg="black", fg="lime", font=("oleo script", 15, "bold")).place(x=120, y=190)
    subject_var = ttk.Combobox(subject_window, font=("oleo script", 15), state="readonly")
    subject_var.place(x=260, y=190)

    Notifica = tk.Label(subject_window, text="", bg="yellow", fg="gold", width=50,
                        height=2, font=("times", 15, "bold"))

    tk.Button(subject_window, text="Check Sheets", command=Attf, bd=7, font=("oleo script", 15), bg="black",
              fg="orange", height=2, width=14, relief="raised").place(x=340, y=260)
    tk.Button(subject_window, text="Fill Attendance", command=FillAttendance, bd=7, font=("oleo script", 15),
              bg="black", fg="orange", height=2, width=14, relief="raised").place(x=100, y=260)

    subject_window.mainloop()
