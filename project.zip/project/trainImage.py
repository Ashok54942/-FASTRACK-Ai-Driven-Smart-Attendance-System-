import os
import cv2
import numpy as np
from PIL import Image
import pandas as pd

def train_image(haar_path, image_folder, model_save_path, message_label, speech_callback):
    recognizer = cv2.face.LBPHFaceRecognizer_create()
    detector = cv2.CascadeClassifier(haar_path)
    mapping_path = "StudentDetails/EnrollmentMapping.csv"

    if not os.path.exists(mapping_path):
        msg = "Enrollment mapping file not found!"
        print(msg)
        message_label.config(text=msg)
        speech_callback(msg)
        return

    df_map = pd.read_csv(mapping_path)
    enrollment_to_id = dict(zip(df_map['Enrollment'], df_map['IntID']))

    def get_images_and_labels(path):
        image_paths = []
        for root, dirs, files in os.walk(path):
            for file in files:
                if file.endswith(".jpg") or file.endswith(".png"):
                    image_paths.append(os.path.join(root, file))

        faces = []
        ids = []

        for image_path in image_paths:
            img = Image.open(image_path).convert("L")
            image_np = np.array(img, "uint8")
            filename = os.path.basename(os.path.dirname(image_path))  # e.g., "BT_CSE_22_001-Karrn"
            enrollment = filename.split("-")[0]

            if enrollment in enrollment_to_id and pd.notna(enrollment_to_id[enrollment]):
                Id = int(enrollment_to_id[enrollment])
                faces.append(image_np)
                ids.append(Id)
            else:
                print(f"Warning: Enrollment {enrollment} not found in mapping CSV.")

        return faces, ids

    faces, ids = get_images_and_labels(image_folder)
    if faces:
        recognizer.train(faces, np.array(ids, dtype='int32'))
        os.makedirs(os.path.dirname(model_save_path), exist_ok=True)
        recognizer.save(model_save_path)
        msg = "Model trained and saved successfully."
        print(msg)
        message_label.config(text=msg)
        speech_callback(msg)
    else:
        msg = "No valid images found for training."
        print(msg)
        message_label.config(text=msg)
        speech_callback(msg)
