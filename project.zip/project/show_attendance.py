import pandas as pd
from glob import glob
import os
import csv
import tkinter as tk
from tkinter import *
from tkinter import ttk, messagebox, filedialog
from fpdf import FPDF
from tkcalendar import DateEntry
from datetime import datetime, timedelta
from openpyxl import load_workbook
import re

subject_data_path = "course.csv"

# New helper function to load and group attendance by 50-minute sessions
def get_filtered_attendance_records(file_list):
    session_duration = timedelta(minutes=2)
    all_records = []
    seen_entries = {}  # key: (Enrollment), value: last timestamp

    for file in sorted(file_list):
        df = pd.read_excel(file)
        if 'Timestamp' not in df.columns:
            continue

        df['Timestamp'] = pd.to_datetime(df['Timestamp'])
        df = df.sort_values(by='Timestamp')

        for _, row in df.iterrows():
            enrollment = row['Enrollment']
            name = row['Name']
            timestamp = row['Timestamp']

            if enrollment not in seen_entries:
                seen_entries[enrollment] = timestamp
                all_records.append({'Enrollment': enrollment, 'Name': name, 'Timestamp': timestamp})
            else:
                last_time = seen_entries[enrollment]
                if (timestamp - last_time) >= session_duration:
                    seen_entries[enrollment] = timestamp
                    all_records.append({'Enrollment': enrollment, 'Name': name, 'Timestamp': timestamp})

    return pd.DataFrame(all_records)

def subjectchoose(text_to_speech):
    def load_subject_data():
        try:
            return pd.read_csv(subject_data_path)
        except FileNotFoundError:
            return pd.DataFrame(columns=["Program", "Semester", "Subject Name"])

    def update_semesters(event):
        selected_program = program_var.get()
        filtered_df = df[df['Program'] == selected_program]
        semester_var['values'] = filtered_df['Semester'].unique().tolist()
        semester_var.set('')
        subject_var.set('')
        subject_var['values'] = []

    def update_subjects(event):
        selected_program = program_var.get()
        selected_semester = semester_var.get()
        filtered_df = df[(df['Program'] == selected_program) & (df['Semester'] == selected_semester)]
        subject_var['values'] = filtered_df['Subject Name'].unique().tolist()
        subject_var.set('')

    def calculate_attendance():
        program = program_var.get()
        semester = semester_var.get()
        subject = subject_var.get()

        if not program or not semester or not subject:
            text_to_speech("Please select program, semester, and subject.")
            return

        subject_folder = os.path.join("Attendance", program, semester, subject)
        if not os.path.exists(subject_folder):
            text_to_speech(f"No folder found for {subject} in selected program and semester.")
            return

        filenames = glob(os.path.join(subject_folder, "*.xlsx"))
        filenames = [f for f in filenames if not f.endswith("attendance.xlsx")]

        if not filenames:
            text_to_speech(f"No attendance records found for {subject}.")
            return

        try:
            combined_df = get_filtered_attendance_records(filenames)
            combined_df.drop_duplicates(inplace=True)

            attendance_summary = combined_df.groupby(['Enrollment', 'Name']).size().reset_index(name='Total Attendance')
            total_sessions = len(set(combined_df['Timestamp'].dt.strftime('%Y-%m-%d %H:%M')))
            attendance_summary['Total Sessions'] = total_sessions
            attendance_summary['Attendance %'] = ((attendance_summary['Total Attendance'] / total_sessions) * 100).round().astype(int).astype(str) + '%'


            final_attendance_file = os.path.join(subject_folder, "attendance.xlsx")
            attendance_summary.to_excel(final_attendance_file, index=False)

            # Auto-fit columns
            wb = load_workbook(final_attendance_file)
            ws = wb.active
            for column_cells in ws.columns:
                max_length = max(len(str(cell.value)) if cell.value else 0 for cell in column_cells)
                adjusted_width = max_length + 2
                col_letter = column_cells[0].column_letter
                ws.column_dimensions[col_letter].width = adjusted_width
            wb.save(final_attendance_file)

            display_summary(attendance_summary, final_attendance_file, program, semester, subject, subject_folder)

        except Exception as e:
            print("Error:", e)
            text_to_speech("An error occurred while calculating attendance.")

    def export_to_excel(df, path):
        df.to_excel(path, index=False)

    def export_to_pdf(df, path):
        pdf = FPDF()
        pdf.add_page()
        pdf.set_font("Arial", size=10)

        col_width = 40
        row_height = 8

        headers = list(df.columns)
        for header in headers:
            pdf.cell(col_width, row_height, header, border=1)
        pdf.ln(row_height)

        for index, row in df.iterrows():
            for item in row:
                pdf.cell(col_width, row_height, str(item), border=1)
            pdf.ln(row_height)

        pdf.output(path)

    def display_summary(df, csv_path, program, semester, subject, subject_folder):
        win = tk.Toplevel()
        win.title(f"Attendance: {program} | {semester} | {subject}")
        win.geometry("950x600")
        win.configure(bg="black")

        search_var = tk.StringVar()
        sort_order = {}

        def treeview_sort_column(col):
            sort_order[col] = not sort_order.get(col, False)
            sorted_df = df.sort_values(by=col, ascending=sort_order[col])
            update_tree(sorted_df)

        def filter_table(*args):
            keyword = search_var.get().lower()
            filtered = df[df.apply(lambda row: keyword in str(row['Enrollment']).lower() or keyword in str(row['Name']).lower(), axis=1)]
            update_tree(filtered)

        def filter_by_date():
            from_date = from_cal.get_date()
            to_date = to_cal.get_date()

            filtered_files = []
            for file in glob(os.path.join(subject_folder, "*.xlsx")):
                if "attendance.xlsx" in file:
                    continue
                filename = os.path.basename(file)
                date_match = re.search(r"\d{4}-\d{2}-\d{2}", filename)
                try:
                    if date_match:
                        file_date = datetime.strptime(date_match.group(), "%Y-%m-%d").date()
                        if from_date <= file_date <= to_date:
                            filtered_files.append(file)
                except Exception as e:
                    print(f"Error parsing file date from {filename}: {e}")
                    continue

            if not filtered_files:
                messagebox.showinfo("No Data", "No attendance records found in selected date range.")
                update_tree(pd.DataFrame())  # <-- Show blank tree
                return

            filtered_df = get_filtered_attendance_records(filtered_files)
            filtered_df.drop_duplicates(inplace=True)
            summary = filtered_df.groupby(['Enrollment', 'Name']).size().reset_index(name='Total Attendance')
            total_sessions = len(set(filtered_df['Timestamp'].dt.strftime('%Y-%m-%d %H:%M')))
            summary['Total Sessions'] = total_sessions
            summary['Attendance %'] = ((summary['Total Attendance'] / total_sessions) * 100).round().astype(int).astype(
                str) + '%'
            update_tree(summary)

        search_frame = tk.Frame(win, bg="black")
        search_frame.pack(pady=5)

        tk.Label(search_frame, text="Search:", font=('Arial', 12), fg="white", bg="black").pack(side=LEFT, padx=5)
        tk.Entry(search_frame, textvariable=search_var, font=('Arial', 12), width=40).pack(side=LEFT)
        search_var.trace("w", filter_table)

        date_frame = tk.Frame(win, bg="black")
        date_frame.pack(pady=5)

        tk.Label(date_frame, text="From:", bg="black", fg="white", font=("Arial", 12)).pack(side=LEFT, padx=5)
        from_cal = DateEntry(date_frame, width=12, background='darkblue', foreground='white', borderwidth=2)
        from_cal.pack(side=LEFT)

        tk.Label(date_frame, text="To:", bg="black", fg="white", font=("Arial", 12)).pack(side=LEFT, padx=5)
        to_cal = DateEntry(date_frame, width=12, background='darkblue', foreground='white', borderwidth=2)
        to_cal.pack(side=LEFT)

        tk.Button(date_frame, text="Filter by Date", command=filter_by_date, font=("Arial", 10, "bold"), bg="orange", fg="black").pack(side=LEFT, padx=10)

        tree = ttk.Treeview(win)
        tree["columns"] = list(df.columns)
        tree["show"] = "headings"

        style = ttk.Style()
        style.configure("Treeview.Heading", font=('Arial', 12, 'bold'), background="black", foreground="orange")
        style.configure("Treeview", font=('Arial', 10), rowheight=25)

        for col in df.columns:
            tree.heading(col, text=col, command=lambda _col=col: treeview_sort_column(_col))
            tree.column(col, width=140, anchor='center')

        tree.pack(fill=tk.BOTH, expand=True, padx=10)

        def update_tree(data):
            for row in tree.get_children():
                tree.delete(row)
            for _, row in data.iterrows():
                tag = ""
                percent = int(row['Attendance %'].replace('%', ''))
                if percent < 75:
                    tag = "low"
                elif percent < 90:
                    tag = "mid"
                else:
                    tag = "high"
                tree.insert("", "end", values=list(row), tags=(tag,))

        tree.tag_configure("low", background="#ffcccc")
        tree.tag_configure("mid", background="#fff0b3")
        tree.tag_configure("high", background="#ccffcc")

        update_tree(df)

        btn_frame = tk.Frame(win, bg="black")
        btn_frame.pack(pady=10)

        def open_excel():
            os.startfile(csv_path)

        def export_excel():
            path = filedialog.asksaveasfilename(defaultextension=".xlsx", filetypes=[("Excel Files", "*.xlsx")])
            if path:
                export_to_excel(df, path)
                messagebox.showinfo("Exported", "Attendance exported as Excel file.")

        def export_pdf():
            path = filedialog.asksaveasfilename(defaultextension=".pdf", filetypes=[("PDF Files", "*.pdf")])
            if path:
                export_to_pdf(df, path)
                messagebox.showinfo("Exported", "Attendance exported as PDF.")

        tk.Button(btn_frame, text="Open in Excel", command=open_excel, font=("Arial", 12, "bold"), bg="green", fg="white", padx=10).pack(side=LEFT, padx=10)
        tk.Button(btn_frame, text="Export as Excel", command=export_excel, font=("Arial", 12, "bold"), bg="blue", fg="white", padx=10).pack(side=LEFT, padx=10)
        tk.Button(btn_frame, text="Export as PDF", command=export_pdf, font=("Arial", 12, "bold"), bg="red", fg="white", padx=10).pack(side=LEFT, padx=10)

    subject_window = Tk()
    subject_window.title("View Attendance")
    subject_window.geometry("600x350")
    subject_window.resizable(0, 0)
    subject_window.configure(background="black")

    tk.Label(subject_window, bg="black", relief=tk.RIDGE, bd=10, font=("arial", 35), text="Select Subject").pack(fill=tk.X)
    tk.Label(subject_window, text="View Attendance", bg="black", fg="sky blue", font=("Arial Rounded MT Bold", 30, "bold")).place(x=140, y=10)

    df = load_subject_data()

    tk.Label(subject_window, text="Program :", bg="black", fg="lime", font=("oleo script", 15, "bold")).place(x=80, y=90)
    program_var = ttk.Combobox(subject_window, values=df['Program'].unique().tolist(), font=("oleo script", 15), state="readonly")
    program_var.place(x=245, y=90)
    program_var.bind("<<ComboboxSelected>>", update_semesters)

    tk.Label(subject_window, text="Semester :", bg="black", fg="lime", font=("oleo script", 15, "bold")).place(x=80, y=140)
    semester_var = ttk.Combobox(subject_window, font=("oleo script", 15), state="readonly")
    semester_var.place(x=245, y=140)
    semester_var.bind("<<ComboboxSelected>>", update_subjects)

    tk.Label(subject_window, text="Subject :", bg="black", fg="lime", font=("oleo script", 15, "bold")).place(x=80, y=190)
    subject_var = ttk.Combobox(subject_window, font=("oleo script", 15), state="readonly")
    subject_var.place(x=245, y=190)

    tk.Button(subject_window, text="View Attendance", command=calculate_attendance, bd=7, font=("oleo script", 15), bg="black", fg="orange", height=2, width=18, relief="raised").place(x=220, y=250)

    subject_window.mainloop()
